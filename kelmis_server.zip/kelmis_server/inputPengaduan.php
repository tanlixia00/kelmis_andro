<?php

include 'koneksi.php';

$nama = $_GET['nama']; //id customer
$alamat = $_GET['alamat'];
$telp = $_GET['telp'];
$id_pel = $_GET['idp'];
$jenis = $_GET['jenis'];
$catatan = $_GET['ket'];

//insert table pengaduan
$sql = "INSERT INTO pengaduanmasyarakat (nama, alamat,  no_tlp, no_idpelanggan, jenis_pengaduan, catatan) values(?,?,?,?,?,?)";
$stmt = $mysqli->prepare($sql);
// echo $url." ".$alasan." ".$lokasi." ".$telp; //for debug
$stmt->bind_param("ssssss", $nama, $alamat, $telp, $id_pel, $jenis, $catatan);
$stmt->execute();
if ($stmt->affected_rows > 0)
{
  echo json_encode(array('result' => 'OK', 'data' => "data masuk"));
} else {
  echo json_encode(array('result'=> 'ERROR', 'message' => 'No data found'));
  die();
}

?>