<?php  
//buka koneksi diawal halaman
//host, username, passw, DBname
$mysqli = new mysqli("localhost", "root", "", "kelmis");
if ($mysqli->connect_errno) {
                echo "Failed to connect to MySQL: " . $mysqli->connect_error;
            }


?>